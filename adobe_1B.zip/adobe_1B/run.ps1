docker run --rm `
  -v "${PWD}\app\input:/app/input" `
  -v "${PWD}\app\output:/app/output" `
  adobe_1b