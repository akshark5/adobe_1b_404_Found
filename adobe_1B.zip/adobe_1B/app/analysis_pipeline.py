import os
import json
import time
import fitz  
import re
import unicodedata
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def extract_keywords(text, top_k=10):
    vectorizer = TfidfVectorizer(stop_words='english', max_features=100)
    X = vectorizer.fit_transform([text])
    feature_names = vectorizer.get_feature_names_out()
    tfidf_scores = X.toarray()[0]
    top_indices = tfidf_scores.argsort()[-top_k:][::-1]
    return [feature_names[i] for i in top_indices if tfidf_scores[i] > 0]

def normalize_unicode(text):
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("utf-8")

def clean_text(text):
    text = normalize_unicode(text)
    text = re.sub(r'[\u2022\uf0b7\u00b7\u00a0\u00b0]', ' ', text)
    text = re.sub(r'[\u2013\u2014\u2015\u2212\-\*\+\·\•\–\—]', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def refine_text(text):
    lines = [clean_text(line.strip()) for line in text.splitlines() if clean_text(line.strip())]
    joined = ' '.join(lines)
    joined = re.sub(r'(?<=[a-z]) (?=[A-Z])', '. ', joined)
    if not joined.endswith('.'):
        joined += '.'
    return joined.strip()

def is_probable_heading(line):
    stopwords = {'and','of','the','in','on','for','to','with','a','an','at','by','from','as','is','are','be','or','but'}
    line = line.strip()
    if not line or len(line) > 200 or line.startswith('•') or line[0].isdigit():
        return False
    if line.isupper():
        return True
    words = [w for w in line.split() if w.lower() not in stopwords]
    if len(words) < 2:
        return False
    title_case_ratio = sum(w[0].isupper() for w in words if w and w[0].isalpha()) / len(words)
    return title_case_ratio > 0.7

def is_heading_continuation(line):
    line = line.strip()
    return line and len(line) < 80 and not line.endswith('.') and not line.startswith('•') and not line[0].isdigit()

def extract_sections_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    sections = []
    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text("text")
        lines = [clean_text(line.rstrip()) for line in text.split('\n')]
        current_section = None
        current_section_text = []
        i = 0
        while i < len(lines):
            line = lines[i]
            if is_probable_heading(line):
                heading_lines = [line]
                j = i + 1
                while j < len(lines) and is_heading_continuation(lines[j]):
                    heading_lines.append(lines[j])
                    j += 1
                heading = " ".join(heading_lines).strip()
                if current_section and len(' '.join(current_section_text)) > 40:
                    sections.append({
                        'document': os.path.basename(pdf_path),
                        'page': page_num + 1,
                        'section_title': current_section,
                        'text': '\n'.join(current_section_text).strip()
                    })
                current_section = heading
                current_section_text = []
                i = j
            else:
                if current_section and line.strip():
                    current_section_text.append(line)
                i += 1
        if current_section and len(' '.join(current_section_text)) > 40:
            sections.append({
                'document': os.path.basename(pdf_path),
                'page': page_num + 1,
                'section_title': current_section,
                'text': '\n'.join(current_section_text).strip()
            })
    return sections

def extract_all_sections(pdf_paths):
    all_sections = []
    for pdf in pdf_paths:
        all_sections.extend(extract_sections_from_pdf(pdf))
    return all_sections

def score_sections(sections, persona, job):
    task_context = f"{persona}. {job}"
    job_keywords = re.findall(r'[a-zA-Z\-]+', job.lower())
    context_keywords = list(set(extract_keywords(task_context, top_k=10) + job_keywords))
    vegetarian_mode = any(word in job.lower() for word in ['vegetarian', 'vegan'])

    contradiction_phrases = ['chicken', 'beef', 'lamb', 'duck', 'mutton', 'fish', 'turkey', 'pork', 'ham', 'bacon', 'shrimp', 'crab', 'anchovy']
    contradiction_vectorizer = TfidfVectorizer(stop_words='english')
    contradiction_matrix = contradiction_vectorizer.fit_transform([' '.join(contradiction_phrases)])
    contradiction_vector = contradiction_matrix.toarray()[0]

    corpus = [section['section_title'] + ' ' + section['text'] for section in sections] + [task_context]
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(corpus)
    job_vec = X[-1]
    section_vecs = X[:-1]
    similarities = cosine_similarity(job_vec, section_vecs).flatten()

    for i, section in enumerate(sections):
        section_text = (section['section_title'] + ' ' + section['text']).lower()
        included = sum(1 for word in context_keywords if word in section_text)
        missing = sum(1 for word in context_keywords if word not in section_text)
        total_keywords = max(len(context_keywords), 1)
        keyword_boost = included / total_keywords
        mismatch_penalty = missing / total_keywords
        length_penalty = 0.1 if len(section['text']) < 40 else 0

        contradiction_penalty = 0
        if vegetarian_mode:
            section_vector = contradiction_vectorizer.transform([section_text]).toarray()[0]
            contradiction_score = cosine_similarity([section_vector], [contradiction_vector])[0][0]
            if contradiction_score > 0.1:
                contradiction_penalty = 1.0

        sections[i]['score'] = (
            float(similarities[i]) + 0.3 * keyword_boost - 0.3 * mismatch_penalty - length_penalty - contradiction_penalty
        )

    return sections

def diversify_top_sections(sections, max_sections=5):
    seen_docs = set()
    top_sections = []
    for section in sorted(sections, key=lambda x: -x['score']):
        if section['document'] not in seen_docs:
            top_sections.append(section)
            seen_docs.add(section['document'])
        if len(top_sections) >= max_sections:
            break
    for section in sorted(sections, key=lambda x: -x['score']):
        if section not in top_sections:
            top_sections.append(section)
        if len(top_sections) >= max_sections:
            break
    return top_sections

def extract_best_paragraph(section, persona, job):
    text = section['text']
    paragraphs = [p.strip() for p in re.split(r'\n\s*\n', text) if len(p.strip()) > 30]
    if not paragraphs:
        paragraphs = [text]
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(paragraphs + [persona + " " + job])
    job_vec = X[-1]
    para_vecs = X[:-1]
    similarities = cosine_similarity(job_vec, para_vecs).flatten()
    best_para = paragraphs[similarities.argmax()]
    return refine_text(best_para)

def generate_output(top_sections, persona, job, input_docs):
    timestamp = datetime.now().isoformat()
    output = {
        "metadata": {
            "input_documents": input_docs,
            "persona": persona,
            "job_to_be_done": job,
            "processing_timestamp": timestamp
        },
        "extracted_sections": [],
        "subsection_analysis": []
    }
    for rank, section in enumerate(top_sections, start=1):
        output["extracted_sections"].append({
            "document": section['document'],
            "page_number": section['page'],
            "section_title": clean_text(section['section_title']),
            "importance_rank": rank
        })
        summary = extract_best_paragraph(section, persona, job)
        output["subsection_analysis"].append({
            "document": section['document'],
            "page_number": section['page'],
            "refined_text": summary
        })
    return output

def run_document_analysis(pdf_paths, persona, job):
    start = time.time()
    sections = extract_all_sections(pdf_paths)
    if not sections:
        raise Exception("No sections found. Check your PDF files or heading detection logic.")
    scored_sections = score_sections(sections, persona, job)
    top_sections = diversify_top_sections(scored_sections, max_sections=5)
    result = generate_output(top_sections, persona, job, [os.path.basename(p) for p in pdf_paths])
    print(f"Processed in {time.time() - start:.2f} seconds")
    return result
