import os
import json
from analysis_pipeline import run_document_analysis

def main():
    input_dir = os.path.join("input", "pdf_files")
    input_json_path = os.path.join("input", "challenge1b_input.json")
    output_dir = "output"
    os.makedirs(output_dir, exist_ok=True)

    with open(input_json_path, "r", encoding="utf-8") as f:
        job_data = json.load(f)

    persona = job_data["persona"]
    job = job_data["job"]

    pdf_paths = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.lower().endswith(".pdf")]
    if not pdf_paths:
        raise Exception("No PDFs found in input/pdf_files/")

    output = run_document_analysis(pdf_paths, persona, job)

    output_path = os.path.join(output_dir, "challenge1b_output.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"Output written to: {output_path}")

if __name__ == "__main__":
    main()
